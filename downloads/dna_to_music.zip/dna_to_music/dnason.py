#!/usr/bin/env python3

# dnason - convert Fasta-format DNA or RNA sequences to music loops in Sonic Pi format

import sys

# BEGIN section the user may wish to change

beat_duration = 0.2  # lower is faster
codon_duration = beat_duration * 3  # 3 bases per codon
codon_amp = 0.2  # codon marker volume
seq_end_sound_sample = ":loop_industrial"  # end-of-sequence sound
seq_end_sound_duration = codon_duration * 3  # for end-of-sequence
seq_end_sound_sleep = seq_end_sound_duration  # for end-of-sequence
notes_per_line = 16  # output formatting

# keys: residue symbols (uppercase), values: notes in Sonic Pi
sounds_dict = {
    "A": ":a",
    "C": ":c",
    "G": ":g",
    "T": "20",
    "U": "20",
    "-": ":r"
}

seq_end_sound = (
    f"  sample {seq_end_sound_sample}, beat_stretch: {seq_end_sound_duration}\n"
    f"  sleep {seq_end_sound_sleep}")

# END section the user may wish to change

if len(sys.argv) != 3 or sys.argv[2] not in ["0", "1"]:
    sys.exit(
        "USAGE: sonify.py <input_file_name> <cds>\n"
        "  <input_file_name> must contain DNA or RNA sequence in Fasta format.\n"
        "  <cds> should be 1 to regard input as codons, or 0 otherwise.")
input_file = sys.argv[1]
is_cds = int(sys.argv[2])
try:
    with open(input_file, 'r') as f:
        lines = f.readlines()
except FileNotFoundError:
    sys.exit(f"ERROR: cannot open file {input_file}")

# convert DNA sequence to notes - melody loop
print("live_loop :melody do")
note_count = 0

for line_number, line in enumerate(lines, start=1):
    line = line.strip()
    if line.startswith(">"):
        note_count = 0
        print("  play_pattern_timed [", end="")
    else:
        residues = list(line.upper())
        for residue in residues:
            if residue not in sounds_dict:
                print(
                    f"WARNING: unknown symbol {residue} at {input_file} line {line_number}",
                    file=sys.stderr)
                residue = "-"

            if note_count > 0:
                print(",", end="")
            if note_count % notes_per_line == 0 and note_count != 0:
                print("\n                      ", end="")

            print(sounds_dict[residue], end="")
            note_count += 1

print(f"], [{beat_duration}]")
print(seq_end_sound)
print("end")

if is_cds:
    # add beat for codon boundaries - bassline loop
    print("live_loop :bassline do")
    print(f"  sample :bass_hit_c, amp: {codon_amp}")
    print(f"  sleep {codon_duration}")
    print("end")
